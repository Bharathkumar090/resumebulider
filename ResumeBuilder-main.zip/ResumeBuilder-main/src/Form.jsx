import { useState } from "react";
import { useNavigate } from "react-router-dom";
import styles from './Form.module.css';

function Form() {
    let navigate = useNavigate();
    const [data, setData] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        skills: [],
        projects: [],
        education: [],
        experience: [],
        check: false
    });

    function HandleChange(e) {
        const { name, value, checked } = e.target;
        if (name === "name" || name === "email" || name === "phone" || name === "address") {
            setData((prev) => ({ ...prev, [name]: value }));
        }

        if (name === "skills" || name === "projects") {
            setData((prev) => ({ ...prev, [name]: (value).split(',') }));
        }

        if (name === "check") {
            setData((prev) => ({ ...prev, [name]: checked }));
        }

        if (name === "education" || name === "experience") {
            let arr = value.split('\n');
            let brr = [];
            arr.forEach((ele) => {
                if (ele.trim() !== "") {
                    brr.push(ele.trim());
                }
            });
            setData((prev) => ({ ...prev, [name]: brr }));
        }
    }

    function Handler(e) {
        e.preventDefault();
        if (!data.check) {
            alert("Please accept the terms and conditions!");
            return;
        }
        navigate("/resume", { state: data });
    }

    return (
        <div className={styles.formContainer}>
            <div className={styles.formCard}>
                <h2 className={styles.formTitle}>Create Your Resume</h2>
                <form className={styles.resumeForm}>

                    <div className={styles.formGroup}>
                        <label htmlFor="name">Full Name</label>
                        <input 
                            type="text" 
                            id="name" 
                            name="name" 
                            onChange={HandleChange}
                            required 
                            minLength={3} 
                            maxLength={25}
                            placeholder="Enter your full name"
                        />
                        <span className={styles.helperText}>3-25 characters</span>
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="email">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            onChange={HandleChange}
                            required 
                            pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                            placeholder="your.email@example.com"
                        />
                        <span className={styles.helperText}>Must be a valid email</span>
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="phone">Phone Number</label>
                        <input 
                            type="tel" 
                            id="phone" 
                            name="phone" 
                            onChange={HandleChange}
                            placeholder="+1 (123) 456-7890"
                        />
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="address">Address</label>
                        <input 
                            type="text" 
                            id="address" 
                            name="address" 
                            onChange={HandleChange}
                            placeholder="City, Country"
                        />
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="skills">Skills</label>
                        <textarea
                            id="skills" 
                            name="skills" 
                            onChange={HandleChange}
                            required 
                            minLength={4}
                            placeholder="JavaScript, React, Node.js (comma separated)"
                        />
                        <span className={styles.helperText}>Separate skills with commas</span>
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="projects">Projects</label>
                        <textarea
                            id="projects" 
                            name="projects" 
                            onChange={HandleChange}
                            required 
                            minLength={4}
                            placeholder="Project 1, Project 2 (comma separated)"
                        />
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="education">Education</label>
                        <textarea
                            id="education" 
                            name="education" 
                            onChange={HandleChange}
                            required 
                            minLength={6}
                            placeholder="BSc Computer Science | University Name | 2020 | 3.8 GPA (one per line)"
                        />
                        <span className={styles.helperText}>One entry per line</span>
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="experience">Work Experience</label>
                        <textarea
                            id="experience" 
                            name="experience" 
                            onChange={HandleChange}
                            placeholder="Frontend Developer | Company Name | 2020-2022 | Responsibilities... (one per line)"
                        />
                    </div>

                    <div className={styles.checkboxGroup}>
                        <input 
                            type="checkbox" 
                            id="conditions" 
                            name="check" 
                            onChange={HandleChange} 
                            checked={data.check}
                            required
                        />
                        <label htmlFor="conditions">I agree to the terms and conditions</label>
                    </div>

                    <button 
                        type="submit" 
                        className={styles.submitButton} 
                        onClick={Handler}
                    >
                        Generate Resume
                    </button>
                </form>
            </div>
        </div>
    );
}

export default Form;