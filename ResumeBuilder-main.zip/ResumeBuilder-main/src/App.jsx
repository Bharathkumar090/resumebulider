import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Form from './Form.jsx'
import Resume from './Template.jsx';
import {Routes,Route} from 'react-router-dom'
function App() {

  return (
    <>
    <Routes>
      <Route path="/" element={<Form/>}/>
      <Route path="/resume" element={<Resume/>}/>
    </Routes>

    </>
  )
}

export default App
