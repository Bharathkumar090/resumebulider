import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import styles from './Template.module.css';

function Resume() {
    const [resumeData, setResumeData] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        skills: [],
        projects: [],
        education: [],
        experience: []
    });
    
    const location = useLocation();

    useEffect(() => {
        if (location.state) {
            setResumeData(location.state);
        }
    }, [location.state]);

    const handlePrint = () => {
        window.print();
    };

    return (
        <div className={styles.resumeContainer}>
            <div className={styles.resumePaper}>
                <header className={styles.resumeHeader}>
                    <div>
                        <h1>{resumeData.name}</h1>
                        <p className={styles.profession}>Web Developer</p>
                    </div>
                    <div className={styles.contactInfo}>
                        <p>{resumeData.email}</p>
                        <p>{resumeData.phone}</p>
                        <p>{resumeData.address}</p>
                    </div>
                </header>

                <section className={styles.resumeSection}>
                    <h2>Summary</h2>
                    <p>Detail-oriented web developer with expertise in modern JavaScript frameworks. Passionate about creating responsive and user-friendly web applications.</p>
                </section>

                <div className={styles.twoColumn}>
                    <section className={styles.resumeSection}>
                        <h2>Skills</h2>
                        <ul className={styles.skillsList}>
                            {resumeData.skills.map((skill, index) => (
                                <li key={index}>{skill}</li>
                            ))}
                        </ul>
                    </section>

                    <section className={styles.resumeSection}>
                        <h2>Projects</h2>
                        <ul>
                            {resumeData.projects.map((project, index) => (
                                <li key={index}>{project}</li>
                            ))}
                        </ul>
                    </section>
                </div>

                <section className={styles.resumeSection}>
                    <h2>Education</h2>
                    {resumeData.education.map((edu, index) => {
                        const parts = edu.split('|').map(part => part.trim());
                        return (
                            <div key={index} className={styles.educationItem}>
                                <h3>{parts[0]}</h3>
                                <p className={styles.institution}>{parts[1]}</p>
                                <p className={styles.duration}>{parts[2]} • {parts[3]}</p>
                            </div>
                        );
                    })}
                </section>

                {resumeData.experience && resumeData.experience.length > 0 && (
                    <section className={styles.resumeSection}>
                        <h2>Experience</h2>
                        {resumeData.experience.map((exp, index) => {
                            const parts = exp.split('|').map(part => part.trim());
                            return (
                                <div key={index} className={styles.experienceItem}>
                                    <h3>{parts[0]}</h3>
                                    <p className={styles.company}>{parts[1]}</p>
                                    <p className={styles.duration}>{parts[2]}</p>
                                    <p className={styles.description}>{parts[3]}</p>
                                </div>
                            );
                        })}
                    </section>
                )}

                <div className={styles.actions}>
                    <button onClick={handlePrint} className={styles.printButton}>
                        Download as PDF
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Resume;